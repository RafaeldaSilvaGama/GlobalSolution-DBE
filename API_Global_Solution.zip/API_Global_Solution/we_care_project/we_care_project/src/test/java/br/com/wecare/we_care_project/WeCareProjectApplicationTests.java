package br.com.wecare.we_care_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeCareProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
