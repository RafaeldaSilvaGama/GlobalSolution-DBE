package br.com.wecare.we_care_project.enums;

public enum Roles {

    USER,
    ADMIN
}
